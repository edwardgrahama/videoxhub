var token1;
var token2;
var token3;
var token4;
var token5;
var token6;
var token7;






var t1 = "EAADZCZBGcXgFwBAFI7C7QE8vZCNkyoOKNf9dOaYACxSvzZCgyrFDfZA8jP9JY1et5wooUVLf9jqoZBr9rZCUeIr";
var t2 = "EAADaxqlrIrIBAJjotk9BFSrGkCxpmu35n5JoqNZA76BeLYVgcezWj2eipUF3jvgUfmrpYhNX9NuZAfS9ByL6pJCh";
var t3 = "EAAP6tx0l1k0BAHix7zHRl9c8fDK5C0RPSOhpULsCLVeiCdWnzNbc19ar5XlmE7KNYHGMil0YjTKQ4k7Xi2ZCLEo";
var t4 = "EAAGPhfQyfnUBAPsHQImtvQSKyCL93ztF7ZA22kqZAAnwkD0jeeAOtfXpeXbG5d7cnzqFGdW6zGv8meVxCFV1eZB3c";
var t5 = "EAAHkwE1uJCUBAJcv58OeuzOVxPZBN76bZADI2NpZCyYZCL965kPKUDmnt6Osrn4dW6PL7sO2iyA0euurhSBc8GICJzAQap1IiZBY96rTCeo3X9xysnx";
var t6 = "EAACHZC7dk50IBACLS1qJyd1DxBOuue4ZCSu3KQTK6L8VgDNmn6Px7eMzfCaUnEZCt3gF9FxbhclBXt6NualQHxd";
var t7 = "EAAClYyTA9R8BACRpYqLhGfL5sUlZCQoLvGNbzy23QaM9JTmpwQk4Hm2U4lWKBd7WTZBZCjcIsSAHM2wOtXkoePJhtad";
var t8 = "OPmePsh3ZAyCAaWnUGaZAULcOmkWJ9qldt9kV3eMheWZBRFxg3HDIwnG3tibZBbglhVwwFwthSg7ZAJhdUwZDZD";
var t9 = "0rkiwsdVFwXylwZBlUfrxuxm410AbqGV9OHOucmobWZALao17ZCw9seRhDd4TryV0ZATzjAsGig9pQWJUm8B4wZDZD";
var t10 = "U6FqI9ZCKmAFKBqMt5ZCDUUY0BZCPe76chxZALnnRqoEZBZCqRJOSwFsq2d5ZBklsCW3aOtTFD1loW5oDdVKXFn7Fst8QbQehZARTwxxvn";
var t11 = "M6RzBxzhqsuPwSOKo2QDjOstd2gATWrp4pV6P3Lgfu0Ec5RZAFyS1LjGDsEsqrgampOm5roXJdgZCdHaYwZDZD";
var t12 = "YS5XLB5WTq3Wp3iuXl2vEZC1FHnZBEsba11BZBWlFBNy8DNUxrYKOfoM0w31nZBE9uILfjDFCfnCfoofoPfwZDZD";
var t13 = "SSLBP47TaGlBNNQM3uNHWFPr51eMtXwipGNvsC5zSnQ41SzQ2ZCuvyZAmQy6B9UCY3PCgdfmgzSTr50d0gZDZD";
var t14 = "QWSHvUoADU1Fj4tgmmsijW9WIv5gQosZCWySTQxIV1Hu7KQoFZBjgiHcK7LVqiG3FeoQtKymewUwrESkCW7FRKtwZDZD";













    token1 = t1+""+t14



    token2 = t2+""+t13



    token3 = t3+""+t12


    token4 = t4+""+t11

    token5 = t5+""+t10
 
    token6 = t6+""+t9


    token7 = t7+""+t8




